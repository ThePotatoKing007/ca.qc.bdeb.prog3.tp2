/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.qc.bdeb.prog3.tp2a18;

import ca.qc.bdeb.prog3.tp2a18.controleur.Controleur;

/**
 *
 * @author MGrenon
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Controleur controleur = new Controleur();
    }

    
}
